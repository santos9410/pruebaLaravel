
<?php

 header('Location: public/');
